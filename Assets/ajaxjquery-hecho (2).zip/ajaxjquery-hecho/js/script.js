$(document).ready(function() {
  //jQuery code...
  $('#ginebra').qtip(
  {
    content: {
      url: 'ajax/ginebra.html'
   }
  });
  $('#tonica').qtip(
  {
    content: {
      url: 'ajax/tonica.html'
   }
  });
  $('#reloj').mouseover(function () { 
    $.ajax({
      type: "POST",
      url: "fecha.php",
      data: "formato=H:i:s",
      success: function(hour){
        $('#reloj').html(hour);
      }
    });
  });
});
