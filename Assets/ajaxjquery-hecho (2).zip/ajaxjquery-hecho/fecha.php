<?php
  header("Cache-Control: no-cache"); 
  echo date($_POST['formato']);
?>

